import UploadCard from "./UploadCard";

function RecentUploads() {
  return (
    <div className="space-y-5">

      <UploadCard
        name="RBI_Circular_2026.pdf"
        status="Compliance analysis completed"
      />

      <UploadCard
        name="SEBI_Guidelines.pdf"
        status="Executive summary generated"
      />

      <UploadCard
        name="Banking_Policy.pdf"
        status="Risk score calculated"
      />

    </div>
  );
}

export default RecentUploads;