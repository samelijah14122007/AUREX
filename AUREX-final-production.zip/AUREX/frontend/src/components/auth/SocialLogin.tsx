import { motion } from "framer-motion";

function SocialLogin() {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="
        mt-6
        flex
        h-12
        w-full
        items-center
        justify-center
        rounded-xl
        border
        border-white/10
        bg-white/5
        text-white
        transition-all
        hover:bg-white/10
      "
    >
      Continue with Google
    </motion.button>
  );
}

export default SocialLogin;