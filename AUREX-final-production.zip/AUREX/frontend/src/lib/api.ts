import axios, { type InternalAxiosRequestConfig } from "axios";

/**
 * Central axios instance used by every service in src/services.
 *
 * Base URL comes from VITE_API_BASE_URL (see .env.example) so the
 * frontend can point at any backend (local dev, staging, prod)
 * without code changes.
 */
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:8080",
  headers: {
    "Content-Type": "application/json",
  },
});

const TOKEN_KEY = "aurex_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

// Attach the JWT (if present) to every outgoing request.
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = getToken();
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// If the backend ever responds 401 (missing/expired/invalid token),
// clear the stale token and send the user back to /login so they
// aren't stuck seeing failed requests silently.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      clearToken();
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

/** Shape of the JSON error body returned by GlobalExceptionHandler. */
export type ApiErrorBody = {
  status: number;
  error: string;
  message: string;
  fieldErrors?: Record<string, string>;
};

/** Pulls a human-readable message out of an axios/API error. */
export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const body = error.response?.data as ApiErrorBody | undefined;
    if (body?.message) return body.message;
    if (error.message) return error.message;
  }
  return "Something went wrong. Please try again.";
}
