# API Reference

Base URL: `http://localhost:8080`

All error responses share this shape (see `GlobalExceptionHandler`):

```json
{
  "timestamp": "2026-07-17T12:00:00Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "fieldErrors": { "email": "Invalid email" }
}
```

## Auth (`/api/auth`) - public

### `POST /api/auth/register`
```json
// request
{ "name": "Sam Elijah", "email": "sam@example.com", "password": "secret123" }

// response 200
{ "token": "<jwt>", "message": "User registered successfully" }
```
`409 Conflict` if the email is already registered.

### `POST /api/auth/login`
```json
// request
{ "email": "sam@example.com", "password": "secret123" }

// response 200
{ "token": "<jwt>", "message": "Login successful" }
```
`401 Unauthorized` on bad credentials.

## Auth (protected - requires `Authorization: Bearer <token>`)

### `GET /api/auth/me`
```json
{
  "id": 1,
  "name": "Sam Elijah",
  "email": "sam@example.com",
  "role": "USER",
  "createdAt": "2026-07-01T10:00:00"
}
```

## AI Chat (protected)

**Note:** by default (`ai.provider=mock`) responses come from a local,
offline responder, not real Gemini - see the root README for how to switch
to `ai.provider=gemini`.

### `POST /api/ai/chat`
```json
// request
{ "message": "What is Artificial Intelligence?" }

// response 200
{ "response": "Artificial Intelligence (AI) is ..." }
```
- `400` if `message` is blank.
- `502` if Gemini returns an error or an unparseable response.
- `503` if Gemini is unreachable / times out.
- `422` if the prompt is blocked by Gemini's safety filters.

`POST /api/chat` is kept as a backward-compatible alias with the same
request/response shape.

## Misc

### `GET /api/hello` - public
Simple liveness check, returns a plain welcome string.
