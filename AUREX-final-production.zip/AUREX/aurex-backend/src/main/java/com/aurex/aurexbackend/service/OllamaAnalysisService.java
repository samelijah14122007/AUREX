package com.aurex.aurexbackend.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;

/** Optional local-only enrichment. Failure always returns empty so analysis never fails. */
@Service
public class OllamaAnalysisService {
    private final ObjectMapper mapper; private final HttpClient client; private final String baseUrl,model;
    public OllamaAnalysisService(ObjectMapper mapper,@Value("${ollama.base-url:http://localhost:11434}") String url,@Value("${ollama.model:llama3.2}") String model){this.mapper=mapper;this.baseUrl=url.replaceAll("/+$","");this.model=model;this.client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();}
    public Optional<String> executiveSummary(String request,String level,int score,String modules){try{HttpRequest health=HttpRequest.newBuilder(URI.create(baseUrl+"/api/tags")).timeout(Duration.ofSeconds(2)).GET().build();if(client.send(health,HttpResponse.BodyHandlers.discarding()).statusCode()!=200)return Optional.empty();String prompt="Write one professional banking change executive summary, maximum 90 words. Do not invent facts. Change: "+request+". Assessment: "+level+" risk ("+score+"/100), modules: "+modules+".";String body=mapper.writeValueAsString(Map.of("model",model,"prompt",prompt,"stream",false));HttpRequest call=HttpRequest.newBuilder(URI.create(baseUrl+"/api/generate")).timeout(Duration.ofSeconds(12)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body)).build();HttpResponse<String> response=client.send(call,HttpResponse.BodyHandlers.ofString());if(response.statusCode()!=200)return Optional.empty();Object result=mapper.readValue(response.body(),new TypeReference<Map<String,Object>>(){}).get("response");return result==null?Optional.empty():Optional.of(result.toString().trim()).filter(s->!s.isBlank());}catch(Exception ignored){return Optional.empty();}}
}
