package com.aurex.aurexbackend.controller;
import com.aurex.aurexbackend.dto.*; import com.aurex.aurexbackend.entity.User; import com.aurex.aurexbackend.service.ChangeAnalysisService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.security.core.annotation.AuthenticationPrincipal; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/analyses") @RequiredArgsConstructor
public class AnalysisController { private final ChangeAnalysisService service;
 @PostMapping public AnalysisResponse analyse(@AuthenticationPrincipal User user,@Valid @RequestBody AnalysisRequest request){return service.analyse(user,request.getRequestText());}
 @GetMapping public List<AnalysisResponse> history(@AuthenticationPrincipal User user,@RequestParam(required=false) String q){return service.history(user,q);}
 @GetMapping("/{id}") public AnalysisResponse get(@AuthenticationPrincipal User user,@PathVariable Long id){return service.get(user,id);}
}
