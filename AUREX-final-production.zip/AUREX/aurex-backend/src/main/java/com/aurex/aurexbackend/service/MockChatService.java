package com.aurex.aurexbackend.service;

import com.aurex.aurexbackend.exception.ApiException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 * Default AI provider - active whenever `ai.provider` is `mock` or unset.
 * Exists so the whole app (auth, JWT, the full chat UI round-trip) is
 * fully testable end-to-end without an API key.
 *
 * It does not call any external service - it generates a short,
 * rule-based reply locally. This is clearly not "real AI", but it lets
 * you validate that POST /api/ai/chat is reachable, authenticated, and
 * wired correctly through to the frontend while keeping all data local.
 */
@Service
@ConditionalOnProperty(name = "ai.provider", havingValue = "mock", matchIfMissing = true)
public class MockChatService implements AiChatService {

    @Override
    public String chat(String message) {

        if (message == null || message.isBlank()) {
            throw new ApiException("Message must not be empty", HttpStatus.BAD_REQUEST);
        }

        String reply = buildReply(message.trim());

        return "[Offline banking assistant]\n\n"
                + reply;
    }

    private String buildReply(String message) {
        String lower = message.toLowerCase();

        if (lower.matches(".*\\b(hi|hello|hey)\\b.*")) {
            return "Hello! I am AUREX's local banking assistant. Describe the affected product, control, "
                    + "or rollout scope and I will guide the governed change-analysis workflow.";
        }

        if (lower.contains("?")) {
            return "For \"" + message + "\", begin by documenting the business owner, affected customer "
                    + "journey, controls, and rollback condition. Run a change analysis to receive a tailored risk score and checklist.";
        }

        return "I received: \"" + message + "\". For a governed delivery plan, use New Analysis; AUREX will map banking terms to impacted modules, controls, testing, and deployment steps locally.";
    }
}
