ALTER TABLE users
    ALTER COLUMN name TYPE VARCHAR(120),
    ALTER COLUMN email TYPE VARCHAR(320),
    ALTER COLUMN password TYPE VARCHAR(100),
    ALTER COLUMN role TYPE VARCHAR(32),
    ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE change_requests
    ALTER COLUMN risk_level TYPE VARCHAR(16),
    ALTER COLUMN analysis_json SET NOT NULL,
    ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE change_requests DROP CONSTRAINT fk7rl8n8bt1pppopb6p0se3getl;
ALTER TABLE change_requests
    ADD CONSTRAINT fk_change_requests_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    ADD CONSTRAINT chk_change_requests_risk_score CHECK (risk_score BETWEEN 0 AND 100),
    ADD CONSTRAINT chk_change_requests_confidence_score CHECK (confidence_score BETWEEN 0 AND 100),
    ADD CONSTRAINT chk_change_requests_risk_level CHECK (risk_level IN ('Low', 'Medium', 'High', 'Critical'));

ALTER TABLE users
    ADD CONSTRAINT chk_users_role CHECK (role IN ('USER', 'ADMIN'));

CREATE INDEX idx_change_requests_user_created_at
    ON change_requests (user_id, created_at DESC);

CREATE INDEX idx_change_requests_user_risk_level
    ON change_requests (user_id, risk_level);
