# Local-only development credentials. This file is ignored by Git.
$env:DB_URL="jdbc:postgresql://localhost:5433/aurex"
$env:DB_USERNAME="aurex_app"
$env:DB_PASSWORD="aurex@123"
$env:JWT_SECRET="AUREX_local_jwt_7Jk2!vQ9#nR4@pT8$wX6zM3"
$env:OLLAMA_BASE_URL="http://localhost:11434"
$env:OLLAMA_MODEL="llama3.2"
